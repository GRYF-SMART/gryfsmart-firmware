/* GPL-2.0-or-later, same license as stk500boot.c. CHAIN1 service transport. */
#include "protocol.h"
#define CH_MARK ((uint8_t*)2032)
static uint8_t ch_page[SPM_PAGESIZE], ch_mask, ch_session;
static uint32_t ch_address;
static uint8_t ch_valid(void) { uint8_t v=eeprom_read_byte(CH_MARK); return v==0xA5; }
static void ch_init(void) {
 extern uint8_t __data_start, __data_end, __data_load_start, __bss_start, __bss_end;
 uint16_t src=(uint16_t)&__data_load_start;
 for(uint8_t *p=&__data_start;p<&__data_end;p++) *p=pgm_read_byte_near(src++);
 for(uint8_t *p=&__bss_start;p<&__bss_end;p++) *p=0;
 ch_address=0xFFFFFFFFUL;
}
static void ch_answer(const char *seq,const char *status,const char *payload) {
 char out[CHAIN_LIMIT];snprintf(out,sizeof(out),"Chain=%s,%s,%s",seq,status,payload);ch_seal(out+6);
 for(char *p=out;*p;p++){sendchar(*p);}sendchar('\r');sendchar('\n');
}
static void ch_service(char *line) {
 if(strlen(line)>=CHAIN_LIMIT-12)return;
 uint8_t discover=!strncmp(line,"AT+Discovery=",13), info=!strncmp(line,"AT+ModuleInfo=",14);
 if(!discover&&!info&&strncmp(line,"AT+Chain=",9))return;
 char *p=line+(discover?13:info?14:9);
 if(!discover&&!info&&!ch_check(p))return;
 char *hop=ch_field(&p),*seq=ch_field(&p);uint32_t h,s,a;
 if(!ch_hex(hop,&h)||!ch_hex(seq,&s)||s>65535)return;
 if(h){
  if(h>=35)return;
  char out[CHAIN_LIMIT];
  if(discover||info)snprintf(out,sizeof(out),"AT+Discovery=%lX,%s",h-1,seq);
  else{snprintf(out,sizeof(out),"AT+Chain=%lX,%s,%s",h-1,seq,p);ch_seal(out+9);}
  forward_line(1,out);return;
 }
 char *op=discover||info?"I":ch_field(&p),*addr=discover||info?"0":ch_field(&p),*data=p;
 if(!ch_hex(addr,&a))return;
 const char *error=0;
 if(!strcmp(op,"I")) {
  ch_answer(seq,"OK","S0804-OLD;UNKNOWN;0;BOOT;ATmega644PA;v1-s0804-old;0;0;CHAIN1");return;
 } else if(!strcmp(op,"R")||!strcmp(op,"E")) {
  uint32_t n;if(!ch_hex(data,&n)||!n||n>32||a>(op[0]=='R'?APP_END:2048UL)-n)error="RANGE";
  else{char out[65];for(uint8_t i=0;i<n;i++)sprintf(out+2*i,"%02X",op[0]=='R'?pgm_read_byte_near(a+i):eeprom_read_byte((uint8_t*)(uint16_t)(a+i)));ch_answer(seq,"OK",out);return;}
 } else if(!strcmp(op,"B")) {
  uint32_t crc;if(a!=APP_END||!ch_hex(data,&crc))error="IMAGE";
  else{eeprom_update_byte(CH_MARK,0);eeprom_busy_wait();eeprom_update_dword((uint32_t*)2033,crc);eeprom_busy_wait();status_upload();ch_session=1;ch_mask=0;ch_address=0xFFFFFFFFUL;}
 } else if(!strcmp(op,"Z")) {
  if(!ch_session||ch_valid()||a>=APP_END||a%SPM_PAGESIZE)error="PAGE";
  else{status_upload();memset(ch_page,255,sizeof(ch_page));ch_mask=0;ch_address=a;}
 } else if(!strcmp(op,"D")) {
  if(!ch_session||ch_address>=APP_END||a>=SPM_PAGESIZE||a%32||strlen(data)!=64)error="CHUNK";
  else {for(uint8_t i=0;i<32;i++){int8_t hi=ch_nibble(data[2*i]),lo=ch_nibble(data[2*i+1]);if(hi<0||lo<0){error="HEX";break;}ch_page[a+i]=(hi<<4)|lo;}if(!error){status_upload();ch_mask|=1<<(a/32);}}
 } else if(!strcmp(op,"W")) {
  if(!ch_session||ch_valid()||a!=ch_address||a>=APP_END||ch_mask!=255)error="INCOMPLETE_PAGE";
  else{status_upload();eeprom_busy_wait();boot_page_erase(a);boot_spm_busy_wait();for(uint16_t i=0;i<SPM_PAGESIZE;i+=2)boot_page_fill(a+i,ch_page[i]|((uint16_t)ch_page[i+1]<<8));boot_page_write(a);boot_spm_busy_wait();boot_rww_enable();for(uint16_t i=0;i<SPM_PAGESIZE;i++)if(pgm_read_byte_near(a+i)!=ch_page[i]){error="VERIFY";break;}}
 } else if(!strcmp(op,"C")) {
  if(!ch_session)error="SESSION";
  else{uint32_t crc=0xFFFFFFFFUL;for(uint32_t i=0;i<APP_END;i++){crc=ch_crc32_byte(crc,pgm_read_byte_near(i));if(!(i&255))status_upload();status_tick();}if((crc^0xFFFFFFFFUL)!=eeprom_read_dword((uint32_t*)2033))error="IMAGE_CRC";else{eeprom_update_byte(CH_MARK,0xA5);eeprom_busy_wait();}}
 } else if(!strcmp(op,"X")) {
  if(!ch_valid()||pgm_read_word_near(0)==65535)error="INCOMPLETE_IMAGE";
  else{ch_answer(seq,"OK","START");app_start();}
 } else error="OP";
 ch_answer(seq,error?"ERR":"OK",error?error:"DONE");
}
