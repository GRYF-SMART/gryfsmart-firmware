/* Shared bounded ASCII service protocol. CRC16-CCITT covers the entire body. */
#ifndef GRYF_CHAIN_PROTOCOL_H
#define GRYF_CHAIN_PROTOCOL_H
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define CHAIN_LIMIT 190
static inline uint16_t ch_crc(const char *s){uint16_t c=65535;while(*s){c^=(uint16_t)(uint8_t)*s++<<8;for(uint8_t i=0;i<8;i++)c=c&0x8000?(c<<1)^0x1021:c<<1;}return c;}
static inline int8_t ch_nibble(char c){if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;if(c>='a'&&c<='f')return c-'a'+10;return -1;}
static inline uint8_t ch_hex(const char *s,uint32_t *v){uint8_t n=0;*v=0;if(!*s)return 0;while(*s){int8_t b=ch_nibble(*s++);if(b<0||++n>8)return 0;*v=(*v<<4)|b;}return 1;}
static inline uint8_t ch_check(char *body){char *p=strrchr(body,'*');uint32_t got;if(!p||strlen(p+1)!=4||!ch_hex(p+1,&got))return 0;*p=0;return ch_crc(body)==got;}
static inline void ch_seal(char *body){uint16_t crc=ch_crc(body);sprintf(body+strlen(body),"*%04X",crc);}
static inline char *ch_field(char **p){char *r=*p,*q=strchr(r,',');if(q){*q=0;*p=q+1;}else *p=r+strlen(r);return r;}
static inline uint32_t ch_crc32_byte(uint32_t c,uint8_t b){c^=b;for(uint8_t i=0;i<8;i++)c=c&1?(c>>1)^0xedb88320UL:c>>1;return c;}
#endif

