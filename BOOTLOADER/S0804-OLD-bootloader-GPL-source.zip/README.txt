S0804 OLD bootloader v1-s0804-old; GPL-2.0-or-later.
Complete generated build sources; application source is not included.
Build with AVR GCC (tested 5.4.0), AVR libc, binutils; run sh build.sh.
Source commit: ce80132dcd6f0fcd7f6da798d9b56a4f75d2e0bd
