#!/bin/sh
set -eu
avr-gcc -mmcu=atmega644pa -DF_CPU=11059200UL -Os -g -std=gnu99 -Wall -Wextra -Werror -Wno-main -ffunction-sections -fdata-sections -nostartfiles -Wl,--section-start=.text=0xE000 -Wl,--gc-sections boot.c -o boot.elf
avr-objcopy -O ihex -R .eeprom boot.elf S0804-OLD-bootloader.hex
