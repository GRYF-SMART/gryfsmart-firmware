/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/power.h>
#include <avr/boot.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <stdint.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#if !defined(__AVR_ATmega644PA__) || F_CPU != 11059200UL
#error S0804 OLD bootloader requires ATmega644PA at 11.0592 MHz
#endif
#define APP_END 0xE000UL
#define RESET_WINDOW_TICKS 32400u /* Timer1 /1024 = 10800 Hz: 3 seconds */
static void sendchar(uint8_t c) { while (!(UCSR0A & _BV(UDRE0))) {} UCSR0A = _BV(TXC0); UDR0 = c; }
static void forward_line(uint8_t port,const char *s)
{
    do {
        uint8_t c=*s?*s++:'\r';
        if(port){while(!(UCSR1A&_BV(UDRE1))){} UCSR1A=_BV(TXC1);UDR1=c;}
        else sendchar(c);
        if(c=='\r')break;
    } while(1);
    if(port){while(!(UCSR1A&_BV(UDRE1))){} UDR1='\n';}else sendchar('\n');
}
static void status_upload(void) { TCNT1 = 0; }
static void status_tick(void) {}
static void app_start(void)
{
    /* Flush the START response before disabling USART0. */
    while (!(UCSR0A & _BV(TXC0))) {}
    cli();
    TCCR1B = 0;
    TIMSK0 = TIMSK1 = TIMSK2 = 0;
    UCSR0B = UCSR1B = 0;
    PORTC = 0;
    PORTB |= _BV(PB2) | _BV(PB3) | _BV(PB4);
    wdt_disable();
    __asm__ __volatile__("jmp 0");
    __builtin_unreachable();
}
#include "s0804_old_chain.inc"

void __attribute__((noreturn)) main(void)
{
    cli();
    GPIOR0=(GPIOR0&15)|((MCUSR&15)<<4);
    MCUSR = 0;
    __asm__ __volatile__(".global s0804_old_wdt_disable\ns0804_old_wdt_disable:");
    wdt_disable();
    /* All eight pins drive relay coils, unlike R0806T OLD's PC2..PC7. */
    PORTC = 0;
    DDRC = 0xff;
    uint8_t control = MCUCR | _BV(JTD);
    __asm__ __volatile__("out %0, %1\n\tout %0, %1"
        : : "I" (_SFR_IO_ADDR(MCUCR)), "r" (control) : "memory");
    __asm__ __volatile__(".global s0804_old_gpio_ready\ns0804_old_gpio_ready:");
    clock_prescale_set(clock_div_1);
    EIMSK = PCICR = TIMSK0 = TIMSK1 = TIMSK2 = 0;
    TCCR0A = TCCR0B = TCCR1A = TCCR1B = TCCR2A = TCCR2B = 0;
    UCSR0B = UCSR1B = 0;
    ch_init();
    /* RUN and RX/TX steady ON in boot mode; PRACA OFF. */
    PORTB = (PORTB | _BV(PB4)) & (uint8_t)~(_BV(PB3) | _BV(PB2));
    DDRB |= _BV(PB2) | _BV(PB3) | _BV(PB4);
    UBRR0H = 0;
    UBRR0L = 5; /* 11.0592 MHz /16 /(5+1) = 115200 exactly */
    UCSR0A = _BV(TXC0);
    UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);
    UCSR0B = _BV(RXEN0) | _BV(TXEN0);
    UBRR1H=0; UBRR1L=5; UCSR1A=_BV(TXC1);
    UCSR1C=_BV(UCSZ11)|_BV(UCSZ10); UCSR1B=_BV(RXEN1)|_BV(TXEN1);
    TCNT1 = 0;
    TCCR1B = _BV(CS12) | _BV(CS10);
    char lines[2][200]; /* Ordinary configuration frames can be 199 characters. */
    uint8_t counts[2]={0,0},drops[2]={0,0};
    for (;;) {
      for(uint8_t port=0;port<2;port++) {
        if ((port?UCSR1A:UCSR0A) & _BV(RXC0)) {
            uint8_t error = (port?UCSR1A:UCSR0A) & (_BV(DOR0) | _BV(FE0) | _BV(UPE0));
            uint8_t c = port?UDR1:UDR0;
            uint8_t used=counts[port],drop=drops[port];char *line=lines[port];
            if (error) drop = 1;
            if (c == '\r' || c == '\n') {
                if (!drop && used) {
                    line[used] = 0;
                    /* Servicing requests renews the reset window, without
                     * starting an upload or modifying EEPROM on discovery. */
                    if (!port && (!strncmp(line, "AT+Discovery=", 13) ||
                        !strncmp(line, "AT+ModuleInfo=", 14) ||
                        !strncmp(line, "AT+Chain=", 9))) {
                        TCNT1 = 0;
                        ch_service(line);
                    } else {TCNT1=0;forward_line(port^1,line);}
                }
                used = drop = 0;
            } else if (!drop) {
                if (used < 199) line[used++] = c;
                else drop = 1;
            }
            counts[port]=used;drops[port]=drop;
        }
      }
        if (!ch_session && TCNT1 >= RESET_WINDOW_TICKS && ch_valid() &&
            pgm_read_word_near(0) != 0xffff) {
            /* No response was sent on this path; UART may have TXC cleared. */
            while (!(UCSR0A & _BV(UDRE0))) {}
            _delay_us(200);
            UCSR0B = UCSR1B = 0;
            TCCR1B = 0;
            PORTB |= _BV(PB2) | _BV(PB3) | _BV(PB4);
            __asm__ __volatile__("jmp 0");
        }
    }
}

/* A real reset vector must precede PROGMEM constants in the boot section. */
void reset_vector(void) __attribute__((naked, section(".vectors"), used));
void reset_vector(void) { __asm__ __volatile__("jmp entry"); }
void entry(void) __attribute__((naked, section(".init0"), used));
void entry(void)
{
    __asm__ __volatile__("clr r1\n\tldi r16,hi8(%0)\n\tout %1,r16\n\t"
        "ldi r16,lo8(%0)\n\tout %2,r16\n\tclr r16\n\tout %3,r16\n\trjmp main"
        : : "i" (RAMEND), "I" (_SFR_IO_ADDR(SPH)), "I" (_SFR_IO_ADDR(SPL)),
            "I" (_SFR_IO_ADDR(SREG)));
}
