﻿window.gryfexpert = {
 download: (name, text, type) => { const url=URL.createObjectURL(new Blob([text],{type:type||'text/plain;charset=utf-8'})); const a=document.createElement('a'); a.href=url; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); },
 confirm: text => window.confirm(text),
 dirty: value => { window.gryfexpertUnsaved=value; },
 copy: text => navigator.clipboard.writeText(text)
};
window.addEventListener('beforeunload', e => { if(window.gryfexpertUnsaved){ e.preventDefault(); e.returnValue=''; } });
document.addEventListener('click', e => { const selected=e.target.closest('details.file-menu,details.tools-menu'); document.querySelectorAll('details.file-menu[open],details.tools-menu[open]').forEach(menu=>{if(menu!==selected)menu.open=false;}); const button=e.target.closest('.file-menu-content button'); if(button)button.closest('details').open=false; });
