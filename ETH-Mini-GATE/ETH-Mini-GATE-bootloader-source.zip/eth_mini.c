/* ETH Mini GATE bootloader. SPDX-License-Identifier: GPL-2.0-or-later */
#include <avr/boot.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>

#define APP_END 0x7000U
#define GRYF_MINI 1
#include "eth_network.inc"

static void uart_send(const uint8_t *data, uint16_t count)
{
    UCSR0A = _BV(U2X0) | _BV(TXC0);
    while (count--) {
        while (!(UCSR0A & _BV(UDRE0))) {}
        UDR0 = *data++;
    }
}

static uint8_t uart_receive(uint8_t *data, uint16_t count)
{
    uint32_t wait = 0;
    while (count--) {
        while (!(UCSR0A & _BV(RXC0))) {
            if (++wait == 1500000UL) return 0;
            _delay_us(10);
        }
        uint8_t status = UCSR0A;
        *data++ = UDR0;
        if (status & (_BV(FE0) | _BV(DOR0) | _BV(UPE0))) return 0;
    }
    return 1;
}

void reset_watchdog(void) __attribute__((naked, used, section(".init3")));
void reset_watchdog(void)
{
    MCUSR = 0;
    wdt_disable();
}

int main(void)
{
    /* 16 MHz, 115200 8N1, double speed. */
    UCSR0A = _BV(U2X0);
    UBRR0 = 16;
    UCSR0B = _BV(RXEN0) | _BV(TXEN0);
    UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);

    _delay_ms(100);
    en_init();
    for (uint16_t elapsed = 0;;) {
        if ((UCSR0A & _BV(RXC0)) && UDR0 == '?') {
            en_serial = 1;
            if (en_session()) break;
            en_serial = 0;
        }
        if (en_poll()) break;
        if (elapsed < 10000) ++elapsed;
        if (elapsed == 10000 && en_valid() && pgm_read_word(0) != 0xffff) break;
        _delay_ms(1);
    }

    if (en_available) en_command(16);
    if (en_serial) while (!(UCSR0A & _BV(TXC0))) {}
    UCSR0B = 0;
    SPCR = 0;
    __asm__ __volatile__("jmp 0");
    __builtin_unreachable();
}
