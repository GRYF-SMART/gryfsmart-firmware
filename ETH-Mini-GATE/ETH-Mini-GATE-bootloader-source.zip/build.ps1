param(
    [Parameter(Mandatory=$true)][ValidateRange(1000000,20000000)][int]$ClockHz,
    [string]$ToolchainBin = '',
    [int]$Baud = 115200,
    [ValidateSet("ETH0606T","R0808","R0806T","S0804","ETH-Mini-GATE")][string]$Model="ETH0606T",
    [string]$OutputDirectory=""
)
$ErrorActionPreference = 'Stop'
$expectedClock=if($Model -in @('ETH0606T','ETH-Mini-GATE')){16000000}else{18432000}
if($ClockHz -ne $expectedClock -or $Baud -ne 115200){throw 'Clock/baud does not match module profile.'}
$mcu=if($Model -in @('ETH0606T','R0808')){'atmega2560'}else{'atmega1284p'}
$start=if($mcu -eq 'atmega2560'){'0x3E000'}else{'0x1E000'}
$defines=@('-DGRYF_DUAL_UART','-DGRYF_ETH_NETWORK');if($Model -ne 'ETH0606T'){$defines=@('-DGRYF_USART0',('-DGRYF_MODEL='+$Model))}
$source='stk500boot.c'
$startup=@('-nostartfiles')
$limit=8192
if($Model -eq 'ETH-Mini-GATE'){
    $mcu='atmega328p'
    $start='0x7000'
    $defines=@()
    $source='eth_mini.c'
    $startup=@()
    $limit=4096
}
if (!$ToolchainBin) {
    $candidates = @(
        "$env:LOCALAPPDATA\Arduino15\packages\arduino\tools\avr-gcc\7.3.0-atmel3.6.1-arduino7\bin",
        'C:\Program Files (x86)\Atmel\Studio\7.0\toolchain\avr8\avr8-gnu-toolchain\bin'
    )
    $ToolchainBin = $candidates | Where-Object { Test-Path (Join-Path $_ 'avr-gcc.exe') } | Select-Object -First 1
}
$source='stk500boot.c'
$startup=@('-nostartfiles')
$limit=8192
if($Model -eq 'ETH-Mini-GATE'){
    $mcu='atmega328p'
    $start='0x7000'
    $defines=@()
    $source='eth_mini.c'
    $startup=@()
    $limit=4096
}
if (!$ToolchainBin) { throw 'Podaj -ToolchainBin ze sciezka do avr-gcc.exe.' }
$outDir = Join-Path $PSScriptRoot "build\$Model-$ClockHz-$Baud"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$elf = Join-Path $outDir 'bootloader.elf'
if(!$OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot '..\..'}
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
$hex = Join-Path $OutputDirectory "$Model-bootloader.hex"
& (Join-Path $ToolchainBin 'avr-gcc.exe') "-mmcu=$mcu" @defines "-DF_CPU=${ClockHz}UL" "-DBAUDRATE=$Baud" '-Os' '-Wall' '-Wextra' '-ffunction-sections' '-fdata-sections' '-fno-jump-tables' '-fno-tree-switch-conversion' @startup "-Wl,--section-start=.text=$start" '-Wl,--gc-sections' "-Wl,-Map=$outDir\bootloader.map" (Join-Path $PSScriptRoot $source) '-o' $elf
if ($LASTEXITCODE) { throw 'Kompilacja nie powiodla sie.' }
& (Join-Path $ToolchainBin 'avr-size.exe') $elf
if ($LASTEXITCODE) { throw 'avr-size failed' }
$sections = & (Join-Path $ToolchainBin 'avr-objdump.exe') '-h' $elf
$line = $sections | Where-Object { $_ -match '\s\.text\s' } | Select-Object -First 1
$parts = $line.Trim() -split '\s+'
$dataLine=$sections | Where-Object { $_ -match '\s\.data\s' } | Select-Object -First 1
$dataSize=if($dataLine){[Convert]::ToInt32(($dataLine.Trim() -split '\s+')[2],16)}else{0}
if (([Convert]::ToInt32($parts[2],16)+$dataSize) -gt $limit) { throw "Bootloader przekracza $limit bajtów." }
& (Join-Path $ToolchainBin 'avr-objcopy.exe') '-O' 'ihex' '-R' '.eeprom' $elf $hex
if ($LASTEXITCODE) { throw 'avr-objcopy failed' }
Write-Output "HEX: $hex"


